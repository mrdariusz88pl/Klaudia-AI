
# Klaudia AI – Railway Edition

Instrukcja uruchomienia na Railway:

1. Utwórz projekt i podłącz repozytorium.
2. Dodaj zmienne środowiskowe zgodnie z `.env.example`.
3. Railway automatycznie uruchomi `npm install` i `npm start`.
4. Wejdź na adres `https://<twoj-projekt>.railway.app`.
