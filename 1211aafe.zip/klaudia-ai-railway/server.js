
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({limit:'10mb'}));
app.use(express.static(path.join(__dirname,'public')));

// MySQL connection pool
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  port: process.env.MYSQL_PORT,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE,
  waitForConnections:true,
  connectionLimit:5,
});

// health
app.get('/api/health', (req,res)=> res.json({status:'ok', time:new Date()}));

// sample route to list tools
app.get('/api/tools', async (req,res)=>{
   try {
     const [rows]=await pool.query('SELECT id,name,category,enabled FROM tools LIMIT 500');
     res.json(rows);
   } catch(err){
     console.error(err);
     res.status(500).json({error:'db error'});
   }
});

// fallback
app.get('*',(req,res)=>{
   res.sendFile(path.join(__dirname,'public','index.html'));
});

app.listen(PORT, ()=> console.log('Server running on '+PORT));
