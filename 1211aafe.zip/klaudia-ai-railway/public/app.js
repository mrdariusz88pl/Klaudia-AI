
fetch('/api/health').then(r=>r.json()).then(d=>{
  document.getElementById('status').textContent='OK ('+d.time+')';
}).catch(()=>{
  document.getElementById('status').textContent='Błąd';
});
